challenge -- fastcode mm Benchmark test

ScaleMM v2.4.1  -- http://code.google.com/p/scalemm/
QMM 	v1.12   -- http://code.google.com/p/qiumm/
SAPMM 	v1.01   -- http://code.google.com/p/sapmm/
TOPMM	v3.55   -- http://www.topsoftwaresite.nl/

qmm.test -- my test :D

